BasicFish self-play dataset.

Train dataset Shape: (258280, 15, 15)
Test dataset Shape: (26263, 15, 15)